function sidebar() {


    // return your html component here
    //Make sure to give input search box id as ""

    return `
    <div>Top News</div>
    <div>Latest News</div>
    <div>All News</div>
    <div>Live News</div>

    <input type="text" id="searchbar" placeholder="Search">
    `;
}
export default sidebar;